package com.mycompany.repository;

import org.springframework.data.repository.CrudRepository;

import com.mycompany.entity.Ticket;

public interface TicketRepository extends CrudRepository<Ticket, Long> {
}
