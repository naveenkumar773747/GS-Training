package com.mycompany.service;

import com.mycompany.entity.Release;

public interface ReleaseService {
    Iterable<Release> listReleases();
}


