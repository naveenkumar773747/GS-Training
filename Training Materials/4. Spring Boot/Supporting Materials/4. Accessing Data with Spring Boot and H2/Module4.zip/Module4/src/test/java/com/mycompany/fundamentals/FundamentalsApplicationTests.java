package com.mycompany.fundamentals;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mycompany.repository.ApplicationRepository;

@SpringBootTest
public class FundamentalsApplicationTests {

	@Autowired
	private ApplicationRepository repository;

	@Test
	public void contextLoads() {
		System.out.println("In FundamentalsApplicationTests...");
		assertThat(repository).isNotNull();
	}

}