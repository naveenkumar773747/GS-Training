package com.mycompany.repository;

import org.springframework.data.repository.CrudRepository;

import com.mycompany.entity.Application;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationRepository extends CrudRepository<Application, Long> {
}
