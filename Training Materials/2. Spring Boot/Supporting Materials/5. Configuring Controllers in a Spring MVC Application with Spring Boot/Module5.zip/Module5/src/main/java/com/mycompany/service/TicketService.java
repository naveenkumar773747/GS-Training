package com.mycompany.service;

import com.mycompany.entity.Ticket;

public interface TicketService {
    Iterable<Ticket> listTickets();
}


