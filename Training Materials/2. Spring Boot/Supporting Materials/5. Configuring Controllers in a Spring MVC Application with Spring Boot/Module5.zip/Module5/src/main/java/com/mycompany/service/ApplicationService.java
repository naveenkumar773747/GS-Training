package com.mycompany.service;

import com.mycompany.entity.Application;

public interface ApplicationService {
    Iterable<Application> listApplications();
}


