package com.mycompany.service;

import java.util.List;
import java.util.Optional;

import com.mycompany.entity.Application;

public interface ApplicationService {
    List<Application> listApplications();
    Application findApplication(long id);
}


